import React from "react";
import "./Loginpage.css";
import bg from "./IMAGES/BGIMG.jpg";
import mobbg from "./IMAGES/mobgimg.jpg";
import { Link, useNavigate } from "react-router-dom";
import { useState } from "react";
import axios from "axios";

function Loginpage() {
  const [user, setUser] = useState("");
  const [pass, setPass] = useState("");
  const [error, setError] = useState("");
  const nav = useNavigate();

  const submit = async (event) => {
    event.preventDefault();

    if (!user || !pass) {
      setError("Please enter both username and password.");
      return;
    }

    try {
      const response = await axios.get(
        `http://192.168.138.38:8080/validate/${user}/${pass}`,
        {
          headers: {
            "Content-Type": "application/json",
          },
        }
      );

      if (response.data === true) {
        // Assuming the backend returns 'true' for successful validation
        alert("Login successful");
        nav("/Home");
      } else {
        setPass("");
        setUser("");
        alert("Login Unsuccessful ");
        setError("Wrong Credentials. Please try again.");
      }
    } catch (e) {
      setError("An error occurred while logging in. Please try again.");
      setPass("");
      setUser("");
    }
  };

  return (
    <div>
      <div class="container-fluid">
        <div class="row">
          <div
            id="brandname"
            class="col d-flex  justify-content-center align-items-center "
          >
            <p class=" mt-0 mb-0">HEALTHCARE AI</p>
          </div>
        </div>
        <div
          class="row d-flex  flex-column justify-content-center align-items-center"
          id="form"
        >
          <div class="col-12 col-sm-6 d-flex  flex-column justify-content-center align-items-center mt-5 mt-sm-0">
            <div id="formborder">
              <form
                class="d-flex  flex-column justify-content-center align-items-center"
                onSubmit={submit}
              >
                <div id="loginname">Login</div>
                <div>
                  <div id="emailinput">
                    <label for="">
                      <i class="fa-solid fa-envelope"></i>
                    </label>
                    <input
                      type="email"
                      placeholder="E-Mail"
                      value={user}
                      onChange={(e) => {
                        setUser(e.target.value);
                      }}
                    ></input>
                  </div>
                  <div id="passinput">
                    <label for="">
                      <i class="fa-solid fa-lock"></i>
                    </label>
                    <input
                      value={pass}
                      type="password"
                      placeholder="Password"
                      onChange={(e) => {
                        setPass(e.target.value);
                      }}
                    ></input>
                  </div>
                  <div class="container-fluid">
                    <div class="row">
                      <div
                        id="sub"
                        class="col-12 d-flex  flex-column justify-content-center align-items-center"
                      >
                        <button type="submit">Submit</button>
                      </div>
                    </div>
                  </div>
                  <div id="fp">
                    <a href="#">Forget Password</a>
                  </div>
                </div>
              </form>
            </div>
          </div>
          <div
            id="regside"
            class="col-12 col-sm-6 d-flex  flex-column justify-content-center align-items-center"
          >
            <p class="text-center">
              New here? Don't have an account? To get Started
            </p>

            <Link to="/Register">
              <a>Register Here</a>
            </Link>
          </div>
        </div>
        <footer>
          <div class="container-fluid p-0">
            <div class="row">
              <div
                id="footername"
                class="col d-flex  flex-column justify-content-center align-items-center"
              >
                <p class="m-0">
                  <i class="fa fa-copyright"></i> HEALTHCARE AI 2024
                </p>
                <a>Take Care of your health bY AI</a>
              </div>
            </div>
          </div>
        </footer>
      </div>
    </div>
  );
}

export default Loginpage;
